package com.maid.final_app;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ReportActivity extends AppCompatActivity {

    private EditText locationEditText, severityEditText, descriptionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        locationEditText = findViewById(R.id.locationEditText);
        severityEditText = findViewById(R.id.severityEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        Button submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(v -> submitReport());
    }

    private void submitReport() {
        String location = locationEditText.getText().toString();
        String severity = severityEditText.getText().toString();
        String description = descriptionEditText.getText().toString();

        // Here you can add your Firebase logic to save the report
        // For now, we'll just show a Toast message
        Toast.makeText(this, "Report submitted for: " + location, Toast.LENGTH_SHORT).show();

        // After submitting, return to the MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish(); // Close ReportActivity
    }
}
